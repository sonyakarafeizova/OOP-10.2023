package WorkingWithAbstraction.Ex_Cards;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES

}
