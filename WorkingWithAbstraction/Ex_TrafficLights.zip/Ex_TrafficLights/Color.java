package WorkingWithAbstraction.Ex_TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
